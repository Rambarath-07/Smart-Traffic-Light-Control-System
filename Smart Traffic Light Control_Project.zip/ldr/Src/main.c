#include "stm32f405xx.h"
#include <stdint.h>
#include "traffic.h"
#include "lcd.h"
#include "cmn.h"
#include <stdio.h>

// Sensor pin definitions
#define TRIG1_PIN   8   // PA8
#define ECHO1_PIN   9   // PA9 - TIM1_CH2 (AF1)

#define TRIG2_PIN   2   // PA2
#define ECHO2_PIN   3   // PA3 - TIM2_CH4 (AF1) ✅

#define TRIG3_PIN   6   // PA6
#define ECHO3_PIN   7   // PA7 - TIM3_CH2 (AF2)

#define TRIG4_PIN   4   // PA4
#define ECHO4_PIN   5   // PA5 - TIM2_CH1 (AF1)

volatile uint32_t start_time[4] = { 0 }, end_time[4] = { 0 };
volatile uint32_t echo_duration[4] = { 0 }, distance_cm[4] = { 0 },
		scaled_distance[4] = { 0 };
uint8_t sensor_index = 0;
void lcd_lane_open(uint8_t lane_number);
uint32_t SystemCoreClock = 84000000;


void lcd_lane_open(uint8_t lane_number) {
    char msg[16];
    sprintf(msg, "Lane %d Open", lane_number);
    lprint(0x80, msg);  // Print at first line
}

// ---------- Delay ----------
void delay_us(uint32_t us) {
	SysTick->LOAD = (us * (SystemCoreClock / 1000000)) - 1;
	SysTick->VAL = 0;
	SysTick->CTRL = 5;
	while ((SysTick->CTRL & (1 << 16)) == 0)
		;
	SysTick->CTRL = 0;
}

// ---------- GPIO ----------
void GPIO_Config(void) {
	RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN;

	// TRIG pins as output
	GPIOA->MODER |= (1 << (TRIG1_PIN * 2)) | (1 << (TRIG2_PIN * 2))
			| (1 << (TRIG3_PIN * 2)) | (1 << (TRIG4_PIN * 2));
	GPIOA->OTYPER &= ~((1 << TRIG1_PIN) | (1 << TRIG2_PIN) | (1 << TRIG3_PIN)
			| (1 << TRIG4_PIN));
	GPIOA->PUPDR &= ~((3 << (TRIG1_PIN * 2)) | (3 << (TRIG2_PIN * 2))
			| (3 << (TRIG3_PIN * 2)) | (3 << (TRIG4_PIN * 2)));

	// Echo pins as alternate function
	GPIOA->MODER &= ~((3 << (ECHO1_PIN * 2)) | (3 << (ECHO2_PIN * 2))
			| (3 << (ECHO3_PIN * 2)) | (3 << (ECHO4_PIN * 2)));
	GPIOA->MODER |= (2 << (ECHO1_PIN * 2)) | (2 << (ECHO2_PIN * 2))
			| (2 << (ECHO3_PIN * 2)) | (2 << (ECHO4_PIN * 2));

	// AFR for Echo pins
	GPIOA->AFR[1] |= (1 << ((ECHO1_PIN % 8) * 4)); // PA9 - TIM1_CH2
	GPIOA->AFR[0] |= (1 << ((ECHO2_PIN % 8) * 4)); // PA3 - TIM2_CH4
	GPIOA->AFR[0] |= (2 << ((ECHO3_PIN % 8) * 4)); // PA7 - TIM3_CH2
	GPIOA->AFR[0] |= (1 << ((ECHO4_PIN % 8) * 4)); // PA5 - TIM2_CH1
}

// ---------- Timer Config ----------
void TIM1_Config(void) {
	RCC->APB2ENR |= RCC_APB2ENR_TIM1EN;
	TIM1->PSC = 42 - 1;
	TIM1->CCMR1 |= TIM_CCMR1_CC2S_0;
	TIM1->CCER |= TIM_CCER_CC2E | TIM_CCER_CC2P;
	TIM1->DIER |= TIM_DIER_CC2IE;
	TIM1->CR1 |= TIM_CR1_CEN;
	NVIC_EnableIRQ(TIM1_CC_IRQn);
}

void TIM2_Config(void) {
	RCC->APB1ENR |= RCC_APB1ENR_TIM2EN;
	TIM2->PSC = 42 - 1;

	TIM2->CCMR1 |= TIM_CCMR1_CC1S_0;     // For PA5 - CH1 (Sensor 4)
	TIM2->CCMR2 |= TIM_CCMR2_CC4S_0;     // For PA3 - CH4 (Sensor 2)

	TIM2->CCER |= TIM_CCER_CC1E | TIM_CCER_CC1P;   // Sensor 4
	TIM2->CCER |= TIM_CCER_CC4E | TIM_CCER_CC4P;   // Sensor 2

	TIM2->DIER |= TIM_DIER_CC1IE | TIM_DIER_CC4IE;
	TIM2->CR1 |= TIM_CR1_CEN;
	NVIC_EnableIRQ(TIM2_IRQn);
}

void TIM3_Config(void) {
	RCC->APB1ENR |= RCC_APB1ENR_TIM3EN;
	TIM3->PSC = 42 - 1;
	TIM3->CCMR1 |= TIM_CCMR1_CC2S_0;
	TIM3->CCER |= TIM_CCER_CC2E | TIM_CCER_CC2P;
	TIM3->DIER |= TIM_DIER_CC2IE;
	TIM3->CR1 |= TIM_CR1_CEN;
	NVIC_EnableIRQ(TIM3_IRQn);
}

void TIM4_Config(void) {
	RCC->APB1ENR |= RCC_APB1ENR_TIM4EN;
	TIM4->PSC = 42000 - 1; // 2ms tick
	TIM4->ARR = 100 - 1;   // 200ms
	TIM4->DIER |= TIM_DIER_UIE;
	TIM4->CR1 |= TIM_CR1_CEN;
	NVIC_EnableIRQ(TIM4_IRQn);
}

// ---------- Trigger Pulse ----------
void trigger_sensor(uint8_t index) {
	switch (index) {
	case 0:
		GPIOA->ODR |= (1 << TRIG1_PIN);
		break;
	case 1:
		GPIOA->ODR |= (1 << TRIG2_PIN);
		break;
	case 2:
		GPIOA->ODR |= (1 << TRIG3_PIN);
		break;
	case 3:
		GPIOA->ODR |= (1 << TRIG4_PIN);
		break;
	}

	delay_us(10);

	switch (index) {
	case 0:
		GPIOA->ODR &= ~(1 << TRIG1_PIN);
		break;
	case 1:
		GPIOA->ODR &= ~(1 << TRIG2_PIN);
		break;
	case 2:
		GPIOA->ODR &= ~(1 << TRIG3_PIN);
		break;
	case 3:
		GPIOA->ODR &= ~(1 << TRIG4_PIN);
		break;
	}
}

// ---------- Timer Interrupts ----------
void TIM4_IRQHandler(void) {
	TIM4->SR &= ~TIM_SR_UIF;
	trigger_sensor(sensor_index);
	sensor_index = (sensor_index + 1) % 4;
}

void TIM1_CC_IRQHandler(void) {
	if (TIM1->SR & TIM_SR_CC2IF) {
		TIM1->SR &= ~TIM_SR_CC2IF;
		if (GPIOA->IDR & (1 << ECHO1_PIN)) {
			start_time[0] = TIM1->CCR2;
			TIM1->CCER |= TIM_CCER_CC2P;
		} else {
			end_time[0] = TIM1->CCR2;
			TIM1->CCER &= ~TIM_CCER_CC2P;
			echo_duration[0] =
					(end_time[0] >= start_time[0]) ?
							(end_time[0] - start_time[0]) :
							(0xFFFF - start_time[0] + end_time[0]);
			distance_cm[0] = echo_duration[0] * 0.034 / 2;
			scaled_distance[0] = distance_cm[0];
		}
	}
}

void TIM2_IRQHandler(void) {
	// Sensor 4 - TIM2_CH1
	if (TIM2->SR & TIM_SR_CC1IF) {
		TIM2->SR &= ~TIM_SR_CC1IF;
		if (GPIOA->IDR & (1 << ECHO4_PIN)) {
			start_time[3] = TIM2->CCR1;
			TIM2->CCER |= TIM_CCER_CC1P;
		} else {
			end_time[3] = TIM2->CCR1;
			TIM2->CCER &= ~TIM_CCER_CC1P;
			echo_duration[3] =
					(end_time[3] >= start_time[3]) ?
							(end_time[3] - start_time[3]) :
							(0xFFFF - start_time[3] + end_time[3]);
			distance_cm[3] = echo_duration[3] * 0.034 / 2;
			scaled_distance[3] = distance_cm[3];
		}
	}

	// Sensor 2 - TIM2_CH4
	if (TIM2->SR & TIM_SR_CC4IF) {
		TIM2->SR &= ~TIM_SR_CC4IF;
		if (GPIOA->IDR & (1 << ECHO2_PIN)) {
			start_time[1] = TIM2->CCR4;
			TIM2->CCER |= TIM_CCER_CC4P;
		} else {
			end_time[1] = TIM2->CCR4;
			TIM2->CCER &= ~TIM_CCER_CC4P;
			echo_duration[1] =
					(end_time[1] >= start_time[1]) ?
							(end_time[1] - start_time[1]) :
							(0xFFFF - start_time[1] + end_time[1]);
			distance_cm[1] = echo_duration[1] * 0.034 / 2;
			scaled_distance[1] = distance_cm[1];
		}
	}
}

void TIM3_IRQHandler(void) {
	if (TIM3->SR & TIM_SR_CC2IF) {
		TIM3->SR &= ~TIM_SR_CC2IF;
		if (GPIOA->IDR & (1 << ECHO3_PIN)) {
			start_time[2] = TIM3->CCR2;
			TIM3->CCER |= TIM_CCER_CC2P;
		} else {
			end_time[2] = TIM3->CCR2;
			TIM3->CCER &= ~TIM_CCER_CC2P;
			echo_duration[2] =
					(end_time[2] >= start_time[2]) ?
							(end_time[2] - start_time[2]) :
							(0xFFFF - start_time[2] + end_time[2]);
			distance_cm[2] = echo_duration[2] * 0.034 / 2;
			scaled_distance[2] = distance_cm[2];
		}
	}
}

// ---------- Main ----------
int main(void) {
	GPIO_Config();
	Traffic_GPIO_Config(); // Traffic Light GPIO
	TIM1_Config();  // Sensor 1
	TIM2_Config();  // Sensor 2 and Sensor 4
	TIM3_Config();  // Sensor 3
	TIM4_Config();  // Periodic trigger
	LcdInit();

	//uint32_t prev_distance[4] = { 0xFFFFFFFF, 0xFFFFFFFF, 0xFFFFFFFF, 0xFFFFFFFF }; // Invalid initial values

	while (1) {
	    uint8_t sensor_triggered = 0;
	    uint16_t thresholds[4] = { 10, 100, 10, 100 };

	    // --- Check for vehicle presence ---
	    for (int i = 0; i < 4; i++) {
	        if (scaled_distance[i] <= thresholds[i]) {
	            sensor_triggered = 1;

	            // 1. Turn all lights red
	            turn_all_red();

	            // 2. Yellow for 1 second (before green)
	            set_light(i, 0, 1, 0); // Yellow ON
	            delay_ms(100);

	            // 3. Green for 5 seconds
	            set_light(i, 0, 0, 1); // Green ON
	            lcd_lane_open(i + 1);
	            delay_ms(500);

	            // 4. Back to red
	            set_light(i, 1, 0, 0);
	            break; // Exit loop, handle next cycle
	        }
	    }

	    // --- If no vehicle detected, run sequential cycle ---
	    if (!sensor_triggered) {
	        for (int lane = 0; lane < 4; lane++) {
	            // Check if any sensor detects a vehicle before green
	            uint8_t immediate_trigger = 0;
	            for (int s = 0; s < 4; s++) {
	                if (scaled_distance[s] <= thresholds[s]) {
	                    immediate_trigger = 1;
	                    break;
	                }
	            }
	            if (immediate_trigger) {
	                break; // Exit to handle detection
	            }

	            // Turn all red first
	            turn_all_red();

	            // Yellow for 1 second
	            set_light(lane, 0, 1, 0); // Yellow ON
	            delay_ms(100);

	            // Green for 5 seconds
	            set_light(lane, 0, 0, 1); // Green ON
	            lcd_lane_open(lane + 1);
	            delay_ms(500);

	            // Back to red
	            set_light(lane, 1, 0, 0);
	        }
	    }
	}}
