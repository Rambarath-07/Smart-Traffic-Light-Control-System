#include "traffic.h"

uint8_t red_pins[TL_COUNT]    = {0, 6, 10, 5};  // PC0, PC6, PC10, PB5
uint8_t yellow_pins[TL_COUNT] = {1, 7, 11, 6};  // PC1, PC7, PC11, PB6
uint8_t green_pins[TL_COUNT]  = {2, 8, 12, 7};  // PC2, PC8, PC12, PB7

GPIO_TypeDef* red_ports[TL_COUNT]    = {GPIOC, GPIOC, GPIOC, GPIOB};
GPIO_TypeDef* yellow_ports[TL_COUNT] = {GPIOC, GPIOC, GPIOC, GPIOB};
GPIO_TypeDef* green_ports[TL_COUNT]  = {GPIOC, GPIOC, GPIOC, GPIOB};

// Blocking delay
void delay_ms(uint32_t ms) {
    for (volatile uint32_t i = 0; i < ms * 8000; i++);
}


void Traffic_GPIO_Config(void) {
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOCEN | RCC_AHB1ENR_GPIOBEN;

    for (int i = 0; i < TL_COUNT; i++) {
        red_ports[i]->MODER    |= (1 << (red_pins[i] * 2));
        yellow_ports[i]->MODER |= (1 << (yellow_pins[i] * 2));
        green_ports[i]->MODER  |= (1 << (green_pins[i] * 2));
    }
}

void set_light(uint8_t index, uint8_t red, uint8_t yellow, uint8_t green) {
    if (red) red_ports[index]->ODR |= (1 << red_pins[index]);
    else     red_ports[index]->ODR &= ~(1 << red_pins[index]);

    if (yellow) yellow_ports[index]->ODR |= (1 << yellow_pins[index]);
    else        yellow_ports[index]->ODR &= ~(1 << yellow_pins[index]);

    if (green) green_ports[index]->ODR |= (1 << green_pins[index]);
    else       green_ports[index]->ODR &= ~(1 << green_pins[index]);
}

void turn_all_red(void) {
    for (int i = 0; i < TL_COUNT; i++) {
        set_light(i, 1, 0, 0);
    }
}

// Static variable to track which light is active
static uint8_t current_light = 0;

// Call this function periodically (e.g. in TIM interrupt or main loop)
void traffic_cycle_step(void) {
    turn_all_red(); // Step 1: All red
    set_light(current_light, 0, 1, 0); // Step 2: Yellow warning
    delay_ms(100);
    set_light(current_light, 0, 0, 1); // Step 3: Green ON
    delay_ms(250);
    current_light = (current_light + 1) % TL_COUNT; // Step 4: Move to next
}

