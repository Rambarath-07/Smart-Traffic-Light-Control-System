#ifndef TRAFFIC_H
#define TRAFFIC_H

#include "stm32f405xx.h"
#include <stdint.h>

#define TL_COUNT 4

void Traffic_GPIO_Config(void);
void set_light(uint8_t index, uint8_t red, uint8_t yellow, uint8_t green);
void turn_all_red(void);
void delay_ms(uint32_t ms);
void traffic_cycle_step(void);  // Add this to your .h if not already


#endif // TRAFFIC_H
